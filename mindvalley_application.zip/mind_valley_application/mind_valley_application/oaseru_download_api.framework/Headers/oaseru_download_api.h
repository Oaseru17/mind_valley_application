//
//  oaseru_download_api.h
//  oaseru_download-api
//
//  Created by gHOST on 13/11/17.
//  Copyright © 2017 gHOST. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for oaseru_download_api.
FOUNDATION_EXPORT double oaseru_download_apiVersionNumber;

//! Project version string for oaseru_download_api.
FOUNDATION_EXPORT const unsigned char oaseru_download_apiVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <oaseru_download_api/PublicHeader.h>


