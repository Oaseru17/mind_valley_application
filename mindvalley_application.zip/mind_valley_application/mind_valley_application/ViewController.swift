//
//  ViewController.swift
//  mind_valley_application
//
//  Created by Precious oaseru Johnson on 13/11/17.
//  Copyright © 2017 gHOST. All rights reserved.
//

import UIKit
import oaseru_download_api
class ViewController: UIViewController{
    
    //declaration of variables
    var data:AnyObject!
    var downloadApi:OaseruDownload!
    @IBOutlet weak var nameLbl: UILabel!
    @IBOutlet weak var usernameLbl: UILabel!
    @IBOutlet weak var profileImg: UIImageView!
   
    //set components on load
    override func viewDidLoad() {
        let dictionary = self.data
        
        profileImg?.image = UIImage(named: "placeholder")
        nameLbl.text = (dictionary!["user"] as! [String:AnyObject])["name"] as? String
        usernameLbl.text = "@"+((dictionary!["user"] as! [String:AnyObject])["username"] as! String);
        loadProfileImage()
    }
    
    //Load image using api
    func loadProfileImage(){
        let dictionary = self.data
        
        downloadApi.getFileTypeAny(fetchtype:"url",url_absolute: ((dictionary!["user"] as! [String:AnyObject])["profile_image"] as! [String:AnyObject] )["large"] as! String){
            (result: Data,reason: String) in
            let img:UIImage! = UIImage(data: result)
            self.profileImg?.image = img
            
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

