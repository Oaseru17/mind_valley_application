//
//  main.swift
//  oaseru_download-api
//
//  Created by Precious oaseru Osaro Johnsonon 13/11/17.
//  Copyright © 2017 gHOST. All rights reserved.
//


//This is the class file where all download and cache algorithmn are located
open class OaseruDownload{
    
    //these are the variable declaration
    var task: URLSessionDownloadTask!
    var session: URLSession!
    var cache:NSCache<AnyObject, AnyObject>!
    var downloadDelegate: URLSessionDownloadDelegate!
    
    //this sepcifies how long the cache should be saved before a new request is made
    var cache_age_per_data: Double!
    
    
    // this datahandler saves the data from the url API and assisgns a date
    // which will be used to check if the file should be refetched
    class dataHandler{
        //this is the variable to hold data
        public var data:Data!
        ///this variable holds the date
        public var save_date:Date!
        
        //initialisation of the class
        init(data: Data) {
            self.data = data
            self.save_date = Date()
        }
        
    //function to check data
        public func get_time_interval() -> Double{
            return self.save_date.timeIntervalSinceNow
        }
        
    }
    
    //this function is designed to fetch data from URL Api
    //it includes the fecth type, which can location or url, sincle data can be retrieved from both
    public func fetchFromUrl(fetchtype:String,url_absolute: String, completion: @escaping ( _ return: Data,_ reason: String) -> Void) {
        let url:URL! = URL(string: url_absolute)
        //session task
    task = session.downloadTask(with: url, completionHandler: {(location: URL?, response: URLResponse?, error: Error?)-> Void in
     
        //check to make sure value is retieved
        if (error == nil) {
            var data:Data?
            //check for where to fectch data
            if(fetchtype == "location"){
                   data = try? Data(contentsOf: location!)
            }else{
                   data = try? Data(contentsOf: url!)
            }
            //create data container
            let newData = dataHandler(data: data!)
            //save data to cache
                self.cache.setObject(newData as AnyObject, forKey: url_absolute as AnyObject)
            
            //return completion
            completion(data!,"")
        }else{
            //return error
            let str = "error"
            let data = NSKeyedArchiver.archivedData(withRootObject: str)
             completion(data,"Error Downloading file")
        }
    })
    task.resume()
    }
    
  //function to get data, either from cache , else from http
    public func getFileTypeAny(fetchtype:String,url_absolute: String, completion: @escaping ( _ return: Data,_ reason: String) -> Void) {
        //ceate thread
        DispatchQueue.main.async(execute: { () -> Void in
            //check cache for data
            if (self.cache.object(forKey: url_absolute as AnyObject) != nil){
           //cache is found
                //check cache's age
                if((self.cache.object(forKey: url_absolute  as AnyObject) as! dataHandler).get_time_interval() > self.cache_age_per_data){
                  
                    //fectch from sever
                    self.fetchFromUrl(fetchtype:fetchtype,url_absolute: url_absolute){
                        (result: Data,reason: String) in
                       //return result
                           completion(result,reason)
                    }
                }else{
                 //return found cache data
                    completion((self.cache.object(forKey: url_absolute  as AnyObject) as! dataHandler).data,"")
                }
                
            }else{
                
                //no cache found fectch direct from server
                self.fetchFromUrl(fetchtype:fetchtype,url_absolute: url_absolute){
                      (result: Data,reason: String) in
                    ///return data
                      completion(result,reason)
                }
            }
        })
    }
    
    
 //function to set cache
    public func changeSize(costLimit: Int) {
        self.cache.totalCostLimit = costLimit
    }
 //function to set cache age
    public func changeCacheAge(newAge: Double) {
       self.cache_age_per_data = newAge
    }
    
    //initialization of download api
public init() {
        self.cache = NSCache()
        self.cache.name = "ApiCache"
    
    //cache cost/size at 100mb
        self.cache.totalCostLimit = 100000000
    
    //age of cache set to 300000 seconds
        self.cache_age_per_data = 300000
    
    ///setting session
        let sessionConfig = URLSessionConfiguration.default
        session = URLSession(configuration: sessionConfig)
       task = URLSessionDownloadTask()
  
    }
}
