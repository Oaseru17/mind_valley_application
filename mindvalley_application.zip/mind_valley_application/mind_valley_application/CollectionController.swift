//
//  CollectionController.swift
//  mind_valley_application
//
//  Created by Precious oaseru Johnson on 13/11/17.
//  Copyright © 2017 gHOST. All rights reserved.
//


//impordatat
import UIKit
import oaseru_download_api


class CollectionController: UICollectionViewController, UICollectionViewDelegateFlowLayout{

    //declare variables
     var downloadApi:OaseruDownload!
    var refreshCtrl: UIRefreshControl!
    var tableData:[AnyObject]!
    var sendingData:AnyObject!
    
    //load functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set application variables
        downloadApi = OaseruDownload()
        downloadApi.changeSize(costLimit: 1000000000)
        self.refreshCtrl = UIRefreshControl()
        self.refreshCtrl.addTarget(self, action: #selector(CollectionController.refreshTableView), for: .valueChanged)
        self.collectionView!.refreshControl = self.refreshCtrl
        self.collectionView!.alwaysBounceVertical = true
        self.tableData = []
        
        
        self.refreshCtrl = UIRefreshControl()
        self.refreshCtrl.addTarget(self, action: #selector(CollectionController.refreshTableView), for: .valueChanged)
        self.collectionView!.refreshControl = self.refreshCtrl
        
        refreshTableView()
        
    }
    
    //function on click for collection view, this prepares segue
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.sendingData = self.tableData[indexPath.item]
        //perform segue
        performSegue(withIdentifier: "segue", sender: self)
     
    }
    
    //set collection size
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: view.frame.width / 2, height: 300)
    }
    
    //load collection data
    public func loadData() -> Void{
        
        //perform download operation
        downloadApi.getFileTypeAny(fetchtype: "location",url_absolute:"http://pastebin.com/raw/wgkJgazE"){
            (result: Data,reason: String) in
            do {
                
                //convert returned data to json
                
                let dic = try JSONSerialization.jsonObject(with: result, options: .mutableLeaves) as AnyObject
                self.tableData = dic as? [AnyObject]
                //load data on a thread
                DispatchQueue.main.async(execute: { () -> Void in
                    //reload collection view
                    self.collectionView!.reloadData()
                    self.collectionView!.refreshControl?.endRefreshing()
                })
                
            } catch let error {
                print(error.localizedDescription)
            }
        }
    }
    
    //refresh function
    @objc  func refreshTableView(){
        loadData()
    }
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
   
        //set collection view values
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as UICollectionViewCell
        let image: UIImageView? = cell.contentView.viewWithTag(2) as? UIImageView
     //set image to style
        let screenSize: CGRect = UIScreen.main.bounds
        image?.frame = CGRect(x: 0, y: 0, width: screenSize.width * 0.5, height: 300)
       //set place holder
          image?.image = UIImage(named: "placeholder")
     
        //check data count before loading image
        if(self.tableData.count > 0){
            
           let dictionary = self.tableData[indexPath.item] as! [String:AnyObject]
        
            downloadApi.getFileTypeAny(fetchtype:"url",url_absolute: ((dictionary["user"] as! [String:AnyObject])["profile_image"] as! [String:AnyObject] )["large"] as! String){
                (result: Data,reason: String) in
              //set image
                let img:UIImage! = UIImage(data: result)
    image?.image = img
                
            }
        }
        return cell
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //preparing data for segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     let secondController = segue.destination as! ViewController
        secondController.data = self.sendingData
        secondController.downloadApi = self.downloadApi
    }
    
    // set infinte scroll
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        if offsetY > contentHeight - scrollView.frame.size.height - 320 {
            // add data
            //uncimment to try
         /*   self.tableData = self.tableData + self.tableData
            self.collectionView!.reloadData()
 
 */
        }
    }
   
 
    
    
    
}
